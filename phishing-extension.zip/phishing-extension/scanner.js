const SUSPICIOUS_TLDS = ["zip", "mov", "xyz", "top", "click", "country", "gq", "tk", "ml", "cf", "ga", "work", "support", "rest", "icu"];
const SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "rebrand.ly", "cutt.ly"];
const BRANDS = ["paypal", "google", "microsoft", "apple", "amazon", "netflix", "facebook", "instagram", "syracuse", "chase", "wellsfargo", "bankofamerica", "dropbox", "docusign"];
const BAIT_WORDS = ["login", "signin", "verify", "secure", "account", "update", "suspend", "password", "confirm"];
const TWO_PART_SUFFIXES = ["co.uk", "com.au", "co.jp", "co.in", "com.br", "org.uk"];

const PHISH_LIST = { urls: new Set(), hosts: new Set() };

function normalizeUrl(raw) {
  let s = raw.trim().toLowerCase();
  s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//, "");
  s = s.split("#")[0];
  s = s.replace(/^www\./, "");
  s = s.replace(/\/+$/, "");
  return s;
}

function loadBlocklistFromText(text) {
  for (const line of text.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    const n = normalizeUrl(t);
    if (!n) continue;
    PHISH_LIST.urls.add(n);
    if (!/[\/?]/.test(n)) PHISH_LIST.hosts.add(n);
  }
}

async function loadBlocklist(location) {
  try {
    const res = await fetch(location);
    if (!res.ok) return 0;
    loadBlocklistFromText(await res.text());
    return PHISH_LIST.urls.size;
  } catch (e) {
    return 0;
  }
}

function isListed(raw) {
  const n = normalizeUrl(raw);
  if (PHISH_LIST.urls.has(n) || PHISH_LIST.urls.has(n.split("?")[0])) return true;
  return PHISH_LIST.hosts.has(n.split(/[\/?]/)[0]);
}

function parseUrl(raw) {
  const text = raw.trim();
  if (!text) return null;
  try {
    return new URL(text);
  } catch (e) {
    try {
      return new URL("http://" + text);
    } catch (e2) {
      return null;
    }
  }
}

function registeredDomain(host) {
  const labels = host.split(".");
  const lastTwo = labels.slice(-2).join(".");
  const lastThree = labels.slice(-3).join(".");
  if (TWO_PART_SUFFIXES.includes(lastTwo)) return lastThree;
  return lastTwo;
}

function scanUrl(raw) {
  const url = parseUrl(raw);
  if (!url || !url.hostname) {
    return { ok: false, error: "That doesn't look like a valid link." };
  }

  const reasons = [];
  const add = (points, text) => reasons.push({ points, text });

  const host = url.hostname.toLowerCase();
  const full = raw.trim();
  const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":");
  const reg = registeredDomain(host);
  const regLabel = reg.split(".")[0];
  const tld = host.split(".").pop();
  const subdomains = isIp ? [] : host.split(".").slice(0, -reg.split(".").length);

  if (isListed(full)) add(10, "Listed as a verified phishing site in PhishTank.");
  if (isIp) add(3, "Uses a raw IP address instead of a domain name.");
  if (url.protocol !== "https:") add(2, "Doesn't use HTTPS, so the connection isn't encrypted.");
  if (full.includes("@")) add(3, 'Contains an "@" symbol, which can hide the real destination.');
  if (full.length > 75) add(1, "The link is unusually long.");
  if (subdomains.length >= 3) add(2, "Has many subdomains, which can disguise the real site.");
  if (SUSPICIOUS_TLDS.includes(tld)) add(2, `Uses the .${tld} ending, which is common in phishing links.`);
  if (host.includes("xn--")) add(3, "Uses punycode, which can imitate a trusted domain with lookalike characters.");
  if (SHORTENERS.includes(reg)) add(2, "Is a shortened link, so the real destination is hidden.");
  if ((host.match(/-/g) || []).length >= 3) add(1, "Has several hyphens in the domain name.");

  if (!isIp && /[a-z][0-1]|[0-1][a-z]/.test(regLabel) && /[a-z]/.test(regLabel) && /[01]/.test(regLabel)) {
    add(2, "The domain mixes letters and look-alike digits (like 1 for l or 0 for o).");
  }

  if (!isIp) {
    for (const brand of BRANDS) {
      if (host.includes(brand) && regLabel !== brand) {
        add(3, `Mentions "${brand}" but the site is hosted on ${reg}.`);
        break;
      }
    }
  }

  const baitHits = BAIT_WORDS.filter((w) => (url.pathname + url.search).toLowerCase().includes(w));
  if (baitHits.length >= 2) add(1, `The path contains words often used to bait users (${baitHits.slice(0, 3).join(", ")}).`);

  //add together points from all phishing indicators
  const score = reasons.reduce((sum, r) => sum + r.points, 0);
  
  //Convert the total score into a risk level
  //0-1 points = Low Risk 
  //2-3 points = Medium Risk 
  //4 or more points = High Risk
  const level = score >= 4 ? "High" : score >= 2 ? "Medium" : "Low";

  return {
    ok: true,
    host,
    score,
    level,
    reasons: reasons.map((r) => r.text),
  };
}

if (typeof module !== "undefined") module.exports = { scanUrl, loadBlocklistFromText, PHISH_LIST };
