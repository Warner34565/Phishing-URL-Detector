const BACKEND_URL = null;

const blocklistReady = loadBlocklist(chrome.runtime.getURL("phishtank_urls.txt"));

const urlInput = document.getElementById("url");
const scanButton = document.getElementById("scan");
const resultBox = document.getElementById("result");
const levelEl = document.getElementById("level");
const hostEl = document.getElementById("host");
const reasonsEl = document.getElementById("reasons");
const noteEl = document.getElementById("note");

const pageBox = document.getElementById("page");
const pageSummary = document.getElementById("pageSummary");
const flaggedList = document.getElementById("flaggedList");

function showPageLinks(data) {
  pageBox.hidden = false;
  flaggedList.textContent = "";
  if (!data || data.items.length === 0) {
    pageSummary.textContent = `Checked ${data ? data.total : 0} links. None look suspicious.`;
    return;
  }
  pageSummary.textContent = `Checked ${data.total} links. ${data.items.length} look suspicious. They're outlined on the page.`;
  for (const item of data.items.slice(0, 8)) {
    const li = document.createElement("li");
    li.className = item.level;
    const lvl = document.createElement("span");
    lvl.className = "lvl";
    lvl.textContent = item.level;
    li.appendChild(lvl);
    li.appendChild(document.createTextNode(item.host + " - " + item.reasons[0]));
    flaggedList.appendChild(li);
  }
}

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs && tabs[0];
  if (!tab || !tab.url || !/^https?:/.test(tab.url)) return;
  urlInput.value = tab.url;
  runScan(tab.url).then(show);
  chrome.tabs.sendMessage(tab.id, { type: "getFlagged" }, (data) => {
    if (chrome.runtime.lastError) return;
    showPageLinks(data);
  });
});

async function runScan(raw) {
  await blocklistReady;
  if (BACKEND_URL) {
    try {
      const res = await fetch(`${BACKEND_URL}/scan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: raw }),
      });
      if (res.ok) return await res.json();
    } catch (e) {
    }
  }
  return scanUrl(raw);
}

function show(result) {
  resultBox.hidden = false;
  resultBox.className = "";
  reasonsEl.textContent = "";

  if (!result.ok) {
    resultBox.classList.add("Error");
    levelEl.textContent = "Can't scan this";
    hostEl.textContent = "";
    noteEl.textContent = result.error;
    return;
  }

  resultBox.classList.add(result.level);
  levelEl.textContent = `${result.level} risk`;
  hostEl.textContent = result.host;

  if (result.reasons.length === 0) {
    const li = document.createElement("li");
    li.textContent = "No common phishing signs found.";
    reasonsEl.appendChild(li);
  } else {
    for (const reason of result.reasons) {
      const li = document.createElement("li");
      li.textContent = reason;
      reasonsEl.appendChild(li);
    }
  }
  noteEl.textContent = "This is guidance, not a guarantee. Be careful with links you didn't expect.";
}

async function handleScan() {
  scanButton.disabled = true;
  scanButton.textContent = "Scanning...";
  show(await runScan(urlInput.value));
  scanButton.disabled = false;
  scanButton.textContent = "Scan link";
}

scanButton.addEventListener("click", handleScan);
urlInput.addEventListener("keydown", (e) => { if (e.key === "Enter") handleScan(); });
