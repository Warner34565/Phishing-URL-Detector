import re
from urllib.parse import urlparse

from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

SUSPICIOUS_TLDS = {"zip", "mov", "xyz", "top", "click", "country", "gq", "tk", "ml", "cf", "ga", "work", "support", "rest", "icu"}
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "rebrand.ly", "cutt.ly"}


def scan(raw: str) -> dict:
    raw = raw.strip()
    parsed = urlparse(raw if "://" in raw else "http://" + raw)
    host = (parsed.hostname or "").lower()
    if not host:
        return {"ok": False, "error": "That doesn't look like a valid link."}

    reasons = []
    labels = host.split(".")
    is_ip = bool(re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", host))

    if is_ip:
        reasons.append((3, "Uses a raw IP address instead of a domain name."))
    if parsed.scheme != "https":
        reasons.append((2, "Doesn't use HTTPS, so the connection isn't encrypted."))
    if "@" in raw:
        reasons.append((3, 'Contains an "@" symbol, which can hide the real destination.'))
    if len(raw) > 75:
        reasons.append((1, "The link is unusually long."))
    if len(labels) > 4:
        reasons.append((2, "Has many subdomains, which can disguise the real site."))
    if labels[-1] in SUSPICIOUS_TLDS:
        reasons.append((2, f"Uses the .{labels[-1]} ending, which is common in phishing links."))
    if "xn--" in host:
        reasons.append((3, "Uses punycode, which can imitate a trusted domain with lookalike characters."))
    if ".".join(labels[-2:]) in SHORTENERS:
        reasons.append((2, "Is a shortened link, so the real destination is hidden."))

    score = sum(p for p, _ in reasons)
    level = "High" if score >= 4 else "Medium" if score >= 2 else "Low"
    return {"ok": True, "host": host, "score": score, "level": level, "reasons": [t for _, t in reasons]}


@app.post("/scan")
def scan_route():
    data = request.get_json(silent=True) or {}
    return jsonify(scan(data.get("url", "")))


if __name__ == "__main__":
    app.run(port=5000)
