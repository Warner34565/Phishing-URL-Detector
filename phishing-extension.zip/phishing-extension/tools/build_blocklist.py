import argparse
import csv

parser = argparse.ArgumentParser()
parser.add_argument("csv_path")
parser.add_argument("--out", default="phishtank_urls.txt")
parser.add_argument("--limit", type=int, default=0, help="keep only the first N URLs (0 = all)")
args = parser.parse_args()

seen = set()
with open(args.csv_path, newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        url = (row.get("url") or "").strip()
        if url and url not in seen:
            seen.add(url)
            if args.limit and len(seen) >= args.limit:
                break

with open(args.out, "w", encoding="utf-8") as f:
    f.write("\n".join(sorted(seen)) + "\n")

print(f"Wrote {len(seen)} URLs to {args.out}")
