importScripts("scanner.js");

const COLORS = { High: "#b3261e", Medium: "#c27c00", Low: "#1f7a4d" };
const LABELS = { High: "HIGH", Medium: "MED", Low: "OK" };

const blocklistReady = loadBlocklist(chrome.runtime.getURL("phishtank_urls.txt"));

async function updateBadge(tabId, url) {
  await blocklistReady;
  if (!url || !/^https?:/i.test(url)) {
    chrome.action.setBadgeText({ tabId, text: "" });
    return;
  }
  const result = scanUrl(url);
  if (!result.ok) {
    chrome.action.setBadgeText({ tabId, text: "" });
    return;
  }
  chrome.action.setBadgeText({ tabId, text: LABELS[result.level] });
  chrome.action.setBadgeBackgroundColor({ tabId, color: COLORS[result.level] });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.status === "loading") updateBadge(tabId, tab.url);
});

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (tab) => { if (tab) updateBadge(tabId, tab.url); });
});
