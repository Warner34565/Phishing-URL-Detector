# Phishing Link Scanner (Group 3)

Chrome Extension Guide

## Install in Chrome (no store needed)
1. Unzip this folder.
2. Open chrome://extensions
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the `phishing-extension` folder (the one containing manifest.json).
5. Click the puzzle-piece icon in the toolbar and pin **Phishing Link Scanner**.

## Files
- manifest.json - extension config
- popup.html / popup.css / popup.js - the popup UI
- scanner.js - local URL checks (works with no backend)
- content.js / content.css - scans and outlines links on every page
- phishtank_urls.txt - blocklist the scanner checks (replace with real data)
- tools/build_blocklist.py - converts PhishTank CSV into that file
- background.js - toolbar badge for the current tab
- backend/app.py - Flask starter for the Python backend
