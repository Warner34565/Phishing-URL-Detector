const flagged = new Map();
let ready = false;

function hostOf(href) {
  try { return new URL(href).hostname.toLowerCase(); } catch (e) { return ""; }
}

function regDomain(host) {
  const parts = host.split(".");
  return parts.slice(-2).join(".");
}

function evaluateAnchor(a) {
  const href = a.href;
  if (!/^https?:/i.test(href)) return;
  if (a.dataset.plsRisk !== undefined) return;

  const result = scanUrl(href);
  if (!result.ok) return;

  const text = (a.textContent || "").trim();
  const shown = text.match(/^(?:https?:\/\/)?((?:[a-z0-9-]+\.)+[a-z]{2,})(?:[\/?#].*)?$/i);
  let score = result.score;
  const reasons = result.reasons.slice();
  if (shown) {
    const shownHost = shown[1].toLowerCase();
    if (regDomain(shownHost) !== regDomain(result.host)) {
      reasons.push(`Link text shows ${shownHost} but the link goes to ${result.host}.`);
      score += 3;
    }
  }

  const level = score >= 4 ? "High" : score >= 2 ? "Medium" : "Low";
  a.dataset.plsRisk = level;
  if (level === "Low") return;

  a.title = `Phishing Link Scanner: ${level} risk\n- ${reasons.join("\n- ")}`;
  flagged.set(href, { level, reasons, host: result.host });
}

function scanPage(root) {
  if (!ready) return;
  (root || document).querySelectorAll("a[href]").forEach(evaluateAnchor);
}

loadBlocklist(chrome.runtime.getURL("phishtank_urls.txt")).then(() => {
  ready = true;
  scanPage(document);
});

let pending = false;
new MutationObserver(() => {
  if (pending) return;
  pending = true;
  setTimeout(() => { pending = false; scanPage(document); }, 400);
}).observe(document.documentElement, { childList: true, subtree: true });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "getFlagged") {
    const items = Array.from(flagged.entries()).map(([href, info]) => ({ href, ...info }));
    items.sort((a, b) => (a.level === b.level ? 0 : a.level === "High" ? -1 : 1));
    sendResponse({ total: document.querySelectorAll("a[href]").length, items });
  }
});
